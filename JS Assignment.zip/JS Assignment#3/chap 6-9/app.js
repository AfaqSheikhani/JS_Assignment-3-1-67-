Q1

var a=+prompt('enter a number')
document.write('the value of a is:'+a+"<hr>")

a=++a;
document.write('the value of ++a is:'+a+"<br>")
document.write('now the value of a is:'+a+"<hr>")

a=a++;
document.write('the value of ++a is:'+a+"<br>")
document.write('now the value of a is:'+a+"<hr>")

a=--a;
document.write('the value of ++a is:'+a+"<br>")
document.write('now the value of a is:'+a+"<hr>")

a=a--;
document.write('the value of ++a is:'+a+"<br>")
document.write('now the value of a is:'+a+"<hr>")


q2


var a=2
var b=1

document.write(--a+"<br>")
document.write(--a - --b+"<br>")
document.write(--a - --b + ++b+"<br>")
document.write('result is:'+--a - --b + ++b+b--+"<br>")

q3

var name=prompt('enter your name')
alert('welcome '+name)


q5


var num=+prompt('enter a number')

for(var i=1;i<=10;i++)
 {
    document.write(num+'x'+i+'='+num*i+"<br>")
}

q6


var math=+prompt('enter marks in math')
var eng=+prompt('enter marks in english')
var sci=+prompt('enter marks in science')
var tmark=100
var mathperc=math/tmark*100
var engperc=eng/tmark*100
var sciperc=sci/tmark*100

document.write('subject       total marks       obt marks       percentage'+"<br>")
document.write('math'+tmark+'         '+math+'         '+mathperc+"<br>")
document.write('english'+tmark+'         '+eng+'         '+engperc+"<br>")
document.write('science'+tmark+'         '+sci+'         '+sciperc+"<br>")
document.write('total'+tmark*3+'         '+(sci+eng+math)+'         '+((sci+eng+math)/(tmark*3)*100)+"<br>")























