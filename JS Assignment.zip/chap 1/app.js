
// //q1

 alert('welcome to our website');

// //q2

 alert('Error!please enter a valid password');

// //q3

 alert('welcome to js land\nhappy coding');

// //q4


 alert('welcome to js land');

