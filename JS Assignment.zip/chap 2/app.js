 //q1
 var username
 
 //q2
 var Myname="Arsalan zahoor"
 alert(Myname)


 //q3
 var message;
 message="hello world"
 alert(message)


 //q4
 name=prompt('Enter your name','your name here');
 age=+prompt('Enter your age','your age here');
 profession=prompt('Enter profession name','your profession here');
 alert(name)
 alert(age)
 alert(profession)


//q5


alert('pizza\npizz\npiz\npi\np')


//q6

var email='muhammadarsalanzahoor@gmail.com'
alert('my email addrss is '+email)



//q7


var book='A smarter way to learn JavaScript'
alert('I am trying to learn from the book '+book)




//q8


document.write('i can write html content through js')



//q9

alert('▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬' )